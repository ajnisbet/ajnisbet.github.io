
# coding: utf-8

# In[1]:


from __future__ import division
from __future__ import print_function

import json
import numpy as np
import pandas as pd
import seaborn as sns
import random
import matplotlib.pyplot as plt
import scipy
import matplotlib.cm as cm

get_ipython().magic('matplotlib inline')
sns.set_style('white')


# In[2]:


setup_file_paths = [
    r'C:\dev\digital-fileshare\CampaignSetupFiles\OIQ\OIQ001544_CampaignSetup_20161207.csv',
    r'C:\dev\digital-fileshare\CampaignSetupFiles\OIQ\OIQ000100_CampaignSetup_20161228.csv',
    r'C:\dev\digital-fileshare\CampaignSetupFiles\VAL\VAL001481_CampaignSetup_20161118.csv',
]
setup_file_paths.sort()


# In[3]:


# Load data.
dfs = []
campaign_ids = [p.split('\\')[-1].split('_')[0] for p in setup_file_paths]
for path in setup_file_paths:
    cols = [
        'AggregateType',
        'AggregateName',
        'Store',
        'FirstScanDate',
        'LastScanDate',
        'SalesAmount'
    ]
    df = pd.read_csv(path, dtype={'Store': str}, parse_dates=['FirstScanDate', 'LastScanDate'], usecols=cols)
    # df.drop(df[df.AggregateType == 'Halo'].index, inplace=True)
    dfs.append(df)


# In[4]:


dfs_base = []
dfs_feat = []
dfs_store = []
for df in dfs:
    df_base = df[df.AggregateType == 'Base'].copy().set_index('Store')[['FirstScanDate', 'LastScanDate', 'SalesAmount']]

    df_feat_all = df[df.AggregateType == 'Featured']
    amounts = df_feat_all.groupby('Store').SalesAmount.sum()
    first_dates = df_feat_all.groupby('Store').FirstScanDate.min()
    last_dates = df_feat_all.groupby('Store').LastScanDate.max()
    df_feat = pd.DataFrame({'SalesAmount': amounts, 'FirstScanDate': first_dates, 'LastScanDate': last_dates})
    df_store = df_feat.merge(df_base, how='inner', left_index=True, right_index=True, suffixes=['Feat', 'Base'])

    df_halo_all = df[df.AggregateType == 'Halo']
    amounts = df_halo_all.groupby('Store').SalesAmount.sum()
    first_dates = df_halo_all.groupby('Store').FirstScanDate.min()
    last_dates = df_halo_all.groupby('Store').LastScanDate.max()
    df_halo = pd.DataFrame({'SalesAmountHalo': amounts, 'FirstScanDateHalo': first_dates, 'LastScanDateHalo': last_dates})
    df_store = df_store.merge(df_halo, how='left', left_index=True, right_index=True)

    dfs_base.append(df_base)
    dfs_feat.append(df_feat)
    dfs_store.append(df_store)


# In[5]:


# Plot full raw dataset
upper_q = 0.97
sep_threshold = 1.5
c_ratio = 0.05

    
for df_store, campaign_id, ax in zip(dfs_store, campaign_ids, axes):
    df_store.SalesAmountBase += df_store.SalesAmountFeat + df_store.SalesAmountHalo
    x_raw = df_store.SalesAmountFeat
    y_raw = df_store.SalesAmountBase
    feat_to_base = df_store.SalesAmountFeat / df_store.SalesAmountBase
    
    x_index = x_raw / x_raw.mean() * 100
    y_index = y_raw / y_raw.mean() * 100
    
    # Compute ratio.
    expected_ratio = (x_raw / y_raw).mean()
    lost_sales = y_raw * expected_ratio - x_raw
    lost_sales_clip = lost_sales.clip(0, lost_sales.quantile(0.99))
    lost_sales_rank = lost_sales.rank()
    
    # Save data
    data = {
        'base_index': y_index.tolist(),
        'lost_sales': lost_sales.tolist(),
        'lost_sales_rank': lost_sales_rank.tolist(),
        'lost_sales_clip': lost_sales_clip.tolist(),
        'feat_to_base': (feat_to_base * 100).tolist(),
        'days_since_last_scan': [int(x) for x in (df_store.LastScanDateFeat.max() - df_store.LastScanDateFeat).dt.days.tolist()],
    }
    
    with open('{}.json'.format(campaign_id), 'w') as f:
        json.dump(data, f, indent=4)
    

