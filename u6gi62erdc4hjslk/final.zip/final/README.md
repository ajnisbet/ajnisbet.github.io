To get it working on your machine, you need to start an http server in the folder (like `python -m http.server`), and change line 68 of `app.js` to point at your server's address.

It's in two parts: `export-data.py` which takes in a campaign setup file and does stuff that's too hard in JS, and exports a JSON file. Then `app.js` uses the JSON to make a plot. But it's probably easier to go from the logic:

* Load a campaign setup file.
* For each store, add the featured and halo sales to base sales (we still call this base).
* Find the featured-to-base ratio of each store, and take the mean. This is the expected ftb ratio.
* For each store, compute lost sales as (base_sales * expected_ftb - feat_sales).
* For each store, find base_sales and ftb_ratio as in index, with 100=mean.
* Then, lost_sales, last_featured_scan_date, ftb_ratio, base_sales_index, ftb_index is exported for each store.

The scatter plot:

* The scatter plot has ftb_index on x-axis, and base-index on the y-axis. Both axes go from 0 to 200. 
* All points with ftb_ratio > 100 are coloured green (as they should have lost_sales < 0).
* All points with (lost_sales > the slider value) and (lost_sales > 0) are coloured red.
* The rest are coloured black. 


The line plot:

* Stores are ordered by their amount of lost sales, largest first. The dollar amount of lost sales is on the y-axis.
* The y-axis is limited to ~ the 97th percentile, otherwise outliers mess up the graph scaling.
* Stores with negative lost sales are set to zero.


Then in the choosing box:

* Lost sales coverage is total lost sales in selected stores / total (only considering stores with lost_sales > 0).
* Lost stores coverage is number of selected stores / total stores  with lost_sales > 0.
* Targeting efficiency is the two numbers divided.
* The slider can only select stores with lost sales > 0.
